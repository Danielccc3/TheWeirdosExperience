# Hey there! I'm @iamraj69 on Discord, the creator of this texture pack. 🤍

### DOs:
- You can use this pack for private purposes, such as making videos, uploading screenshots on social media, etc.
- You are free to distribute it anywhere you like **with proper credits.** :)

### DON'Ts: 
- You are not allowed to distribute a modified version of this pack under your name without my consent.

### Giving Credit
- To credit me, you can mention my Discord handle or provide my GitHub link: https://github.com/itsMeRaj69

### Business & Contact:
- Discord: @iamraj69
- Email: royraj70652@gmail.com

**Thank you for reading this far! Have a great day! :D**