✧♢	English Version Below	♢✧

	本资源包由 ALYBH 制作并发布于网络，感谢下载或使用！

	建议·反馈·交流（QQ群）：488050245

相关链接：
	苦力怕论坛：https://klpbbs.com/space-uid-1636799.html
	哔哩哔哩：https://space.bilibili.com/5989446/channel/seriesdetail?sid=3802017
	Modrinth：https://modrinth.com/user/ALYBH
注意事项：
	如果您曾经在其他途径为这个资源包付款，那么请注意，您可能已经上当受骗。


	This resource pack is crafted and published by "ALYBH". Thank you for downloading or using it!

	Suggestions, Feedback, and Communication (QQ Group): 488050245

Related Links:
	KLPBBS：https://klpbbs.com/space-uid-1636799.html
	Bilibili：https://space.bilibili.com/5989446/channel/seriesdetail?sid=3802017
	Modrinth：https://modrinth.com/user/ALYBH
Attention:
	If you have paid for this resource pack in other ways, please note that you may have been deceived.